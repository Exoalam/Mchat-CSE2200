package com.mchat;

import animatefx.animation.FadeIn;
import animatefx.animation.FadeOut;
import animatefx.animation.SlideInDown;
import animatefx.animation.SlideOutUp;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DialogPane;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import org.bson.Document;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Scanner;

public class Login implements Initializable {

    Double x,y;
    Alert alert = new Alert(Alert.AlertType.WARNING);
    Alert alertU = new Alert(Alert.AlertType.WARNING);
    Alert alertE = new Alert(Alert.AlertType.WARNING);
    Alert alertPL = new Alert(Alert.AlertType.WARNING);
    Alert alertUL = new Alert(Alert.AlertType.WARNING);
    public static String username;
    private String Database_Connection = "mongodb+srv://Server:Server1234@mchat.xvkt0.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";
    MongoClient mongoClient = MongoClients.create(Database_Connection);
    MongoCollection<Document> user_database = mongoClient.getDatabase("Users").getCollection("User");
    ArrayList<String> datas = new ArrayList<>();
    List<Document> data = user_database.find().into(new ArrayList<>());
    List<Document> User_data = user_database.find().into(new ArrayList<>());
    public static String ServerIP = "localhost";
    public static int MessagePort = 1234;
    public static int FilePort = 5555;
    @FXML
    private AnchorPane LoginMain;

    @FXML
    private Pane Settings_panel;

    @FXML
    private TextField Defalut_location;

    @FXML
    private TextField FIle_port;

    @FXML
    private TextField Port;

    @FXML
    private TextField serverIP;

    @FXML
    private Button login_settings;



    @FXML
    private AnchorPane panel;

    @FXML
    private TextField Email_field;

    @FXML
    private TextField pass_field;

    @FXML
    private TextField Email_field2;

    @FXML
    private TextField pass_field2;

    @FXML
    private TextField User_field;


    @FXML
    private Pane SignUp_Panel;

    @FXML
    private Pane login_panel;


    @FXML
    private Button buttona;

    @FXML
    private Button LoginButton;

    @FXML
    private Button SignUp_button;

    @FXML
    void Login(ActionEvent event) throws IOException {
        boolean right = true;
        for (Document x : data) {
            if(x.getString("email") != null) {
                if (Email_field.getText().equals(x.getString("email"))) {
                    if (pass_field.getText().equals(x.getString("password"))) {
                        username = x.getString("user");
                        user_database.updateOne(Filters.eq("user", username), Updates.set("Status", "Online"));
                        App.setRoot("/UI");
                        right = false;
                        break;
                    }
                }

            }
        }
        if (right){
            alert.show();
        }
    }
    @FXML
    void SignUP(ActionEvent event) throws IOException {
        boolean c1 = true, c2 = true;
        if(User_field.getText().length() >= 4) {
            if(pass_field2.getText().length() >= 6) {
                for (Document d : User_data) {
                    if(d.getString("user").equals(User_field.getText())){
                        c1 = false;
                        alertU.show();
                        break;
                    }
                }
                for (Document d : User_data) {
                    if(d.getString("email").equals(Email_field2.getText())){
                        c2 = false;
                        alertE.show();
                        break;
                    }

                }
            }
            else {
                alertPL.show();
                c1 = false;
                c2 = false;
            }
        }
        else {
            alertUL.show();
            c1 = false;
            c2 = false;
        }
        if (c1 && c2) {
            Document document = new Document("user", User_field.getText()).append("email", Email_field2.getText())
                    .append("password", pass_field2.getText()).append("Status", "Online").append("Friends", "")
                    .append("Requests", "");
            user_database.insertOne(document);
            username = User_field.getText();
            App.setRoot("/UI");
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        alert.setContentText("Wrong Email or Password");
        alertU.setContentText("UserID Already Exists");
        alertE.setContentText("Email Already Exists");
        alertPL.setContentText("Password Length Needs To Be At Least 6");
        alertUL.setContentText("UserID Length Needs To Be At Least 4");
        alert.initStyle(StageStyle.UNDECORATED);
        alertU.initStyle(StageStyle.UNDECORATED);
        alertE.initStyle(StageStyle.UNDECORATED);
        alertUL.initStyle(StageStyle.UNDECORATED);
        alertPL.initStyle(StageStyle.UNDECORATED);
        DialogPane dialogPane = alert.getDialogPane();
        dialogPane.getStylesheets().add(getClass().getResource("/CSS/UI.css").toExternalForm());
        dialogPane.getStyleClass().add("Dialogs");
        dialogPane = alertU.getDialogPane();
        dialogPane.getStylesheets().add(getClass().getResource("/CSS/UI.css").toExternalForm());
        dialogPane.getStyleClass().add("Dialogs");
        dialogPane = alertE.getDialogPane();
        dialogPane.getStylesheets().add(getClass().getResource("/CSS/UI.css").toExternalForm());
        dialogPane.getStyleClass().add("Dialogs");
        dialogPane = alertUL.getDialogPane();
        dialogPane.getStylesheets().add(getClass().getResource("/CSS/UI.css").toExternalForm());
        dialogPane.getStyleClass().add("Dialogs");
        dialogPane = alertPL.getDialogPane();
        dialogPane.getStylesheets().add(getClass().getResource("/CSS/UI.css").toExternalForm());
        dialogPane.getStyleClass().add("Dialogs");


    }
    @FXML
    void work(ActionEvent event) {
        new SlideOutUp(panel).play();
        new FadeOut(LoginButton).play();
        new FadeOut(SignUp_button).play();
        login_panel.setVisible(true);
        login_panel.setDisable(false);
        LoginButton.setVisible(false);
        LoginButton.setDisable(true);
        SignUp_button.setDisable(true);
        SignUp_button.setVisible(false);
    }
    @FXML
    void work2(ActionEvent event) {
        new SlideOutUp(panel).play();
        new FadeOut(LoginButton).play();
        new FadeOut(SignUp_button).play();
        SignUp_Panel.setVisible(true);
        SignUp_Panel.setDisable(false);
        LoginButton.setVisible(false);
        LoginButton.setDisable(true);
        SignUp_button.setDisable(true);
        SignUp_button.setVisible(false);
    }
    @FXML
    void login_EXit(ActionEvent event) {
        System.exit(0);
    }

    @FXML
    void login_set(ActionEvent event) throws FileNotFoundException {
        new SlideOutUp(panel).play();
        new FadeOut(LoginButton).play();
        new FadeOut(SignUp_button).play();
        LoginButton.setVisible(false);
        LoginButton.setDisable(true);
        SignUp_button.setDisable(true);
        SignUp_button.setVisible(false);
        login_settings.setVisible(false);
        login_settings.setDisable(true);
        Settings_panel.setVisible(true);
        Settings_panel.setDisable(false);
        serverIP.setText(ServerIP);
        Port.setText(String.valueOf(MessagePort));
        FIle_port.setText(String.valueOf(FilePort));
        File df = new File("src/main/catalog.txt");
        Scanner scanner = new Scanner(df);
        Defalut_location.setText(scanner.nextLine());
    }


    @FXML
    void press1(MouseEvent event) {
        x = event.getSceneX();
        y = event.getSceneY();
    }

    @FXML
    void press2(MouseEvent event) {
        x = event.getSceneX();
        y = event.getSceneY();
    }

    @FXML
    void draged1(MouseEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setX(event.getScreenX() - x);
        stage.setY(event.getScreenY() - y);
    }

    @FXML
    void draged2(MouseEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setX(event.getScreenX() - x);
        stage.setY(event.getScreenY() - y);
    }


    @FXML
    void back1(ActionEvent event) {
        new SlideInDown(panel).play();
        new FadeIn(LoginButton).play();
        new FadeIn(SignUp_button).play();
        SignUp_Panel.setVisible(false);
        SignUp_Panel.setDisable(true);
        LoginButton.setVisible(true);
        LoginButton.setDisable(false);
        SignUp_button.setDisable(false);
        SignUp_button.setVisible(true);
    }
    @FXML
    void back2(ActionEvent event) {
        new SlideInDown(panel).play();
        new FadeIn(LoginButton).play();
        new FadeIn(SignUp_button).play();
        login_panel.setVisible(false);
        login_panel.setDisable(true);
        LoginButton.setVisible(true);
        LoginButton.setDisable(false);
        SignUp_button.setDisable(false);
        SignUp_button.setVisible(true);
    }

    @FXML
    void save(ActionEvent event) {
        ServerIP = serverIP.getText();
        MessagePort = Integer.valueOf(Port.getText());
        FilePort = Integer.valueOf(FIle_port.getText());
        Controller.Default_download = Defalut_location.getText();
    }

    @FXML
    void back3(ActionEvent event) {
        new SlideInDown(panel).play();
        new FadeIn(LoginButton).play();
        new FadeIn(SignUp_button).play();
        Settings_panel.setVisible(false);
        Settings_panel.setDisable(true);
        LoginButton.setVisible(true);
        LoginButton.setDisable(false);
        SignUp_button.setDisable(false);
        SignUp_button.setVisible(true);
        login_settings.setDisable(false);
        login_settings.setVisible(true);
    }
    @FXML
    void Browser(ActionEvent event) throws IOException {
        DirectoryChooser directoryChooser = new DirectoryChooser();
        File file = directoryChooser.showDialog(null);
        Defalut_location.setText(file.getPath());
        File df = new File("src/main/catalog.txt");
        FileWriter fileWriter = new FileWriter(df);
        fileWriter.write(file.getPath() + "\\");
        fileWriter.close();
    }


}
