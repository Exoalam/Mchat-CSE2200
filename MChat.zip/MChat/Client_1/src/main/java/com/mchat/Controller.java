package com.mchat;

import animatefx.animation.SlideInRight;
import animatefx.animation.SlideOutRight;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.bson.Document;

import java.io.*;
import java.net.Socket;
import java.net.URL;
import java.util.*;

public class Controller implements Initializable {
    double x,y;
    boolean sent = true;
    public static String Default_download;
    Thread receive_message, receive_file;
    public static String message;
    Document userDoc;
    private String Database_Connection = "mongodb+srv://Server:Server1234@mchat.xvkt0.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";
    MongoClient mongoClient = MongoClients.create(Database_Connection);
    MongoCollection<Document> Chat_database = mongoClient.getDatabase("chat").getCollection("chitchat");
    MongoCollection<Document> user_database = mongoClient.getDatabase("Users").getCollection("User");
    List<Document> data = Chat_database.find().into(new ArrayList<>());
    @FXML
    private AnchorPane Maximus;
    @FXML
    private TextArea Messeging_text;

    @FXML
    private VBox Message_UI;

    @FXML
    private ListView<HBox> Friend_list;
    @FXML
    private ScrollPane scroller;
    @FXML
    private HBox message_sending_panel;

    @FXML
    private TextField download_location;

    @FXML
    private AnchorPane Settings_windows;

    @FXML
    private TextField Search_friends;

    @FXML
    private AnchorPane Add_friend_panel;

    @FXML
    private ListView<String> search_list;

    @FXML
    private ListView<String> Request_list;

    String person_to_talk;
    ArrayList<String> messages_array = new ArrayList<>();
    File df = new File("src/main/catalog.txt");
    Scanner scanner = new Scanner(df);
    Socket socket = new Socket(Login.ServerIP,Login.MessagePort);
    Socket socketF = new Socket(Login.ServerIP, Login.FilePort);
    DataInputStream input_Data = new DataInputStream(socketF.getInputStream());
    DataOutputStream dataOutputStream = new DataOutputStream(socketF.getOutputStream());
    static float outputUI;
    int read_data;
    long file_size;
    long file_Max;
    int user_pos;
    DataInputStream input = new DataInputStream(socket.getInputStream());
    DataOutputStream output = new DataOutputStream(socket.getOutputStream());
    ArrayList<Document> User_list = new ArrayList<>();
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Default_download = scanner.nextLine();
        download_location.setText(Default_download);
        User_list.addAll(user_database.find().into(new ArrayList<>()));
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                new SlideOutRight(scroller).play();
                new SlideOutRight(message_sending_panel).play();
                for (Document x : User_list) {
                    if (!x.getString("user").equals(Login.username)) {
                        Friend_list.getItems().add(friend_list(x.getString("user"), x.getString("Status")));
                    }
                    else {
                        user_pos = User_list.indexOf(x);
                        userDoc = new Document(x);
                    }
                }
                Friend_list.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
                for (Document y : data) {
                    StringTokenizer split = new StringTokenizer(y.getString("Message"),"#");
                    String message = split.nextToken();
                    String ID = split.nextToken();
                    if (ID.equals(Login.username)) {
                        try {
                            message_receive(y.getString("ID") + " -> " + message);
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }
                    }
                    else if (y.getString("ID").equals(Login.username)) {
                        try {
                            message_send(message);
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });
        try {
            output.writeUTF(Login.username);
            dataOutputStream.writeUTF(Login.username);
        } catch (IOException e) {
            e.printStackTrace();
        }
        search_list.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        Request_list.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
    }

    public void message_send(String message) throws FileNotFoundException {
        Label label = new Label();
        label.setWrapText(true);
        label.setFont(new Font(15));
        label.setMaxWidth(180);
        label.setText(message);
        label.setPadding(new Insets(10,10,10,10));
        label.setTextFill(Color.valueOf("#cdbe91"));
        label.setStyle("-fx-border-width: 3;-fx-border-color: #785A28;-fx-border-radius: 20;");
        Image image = new Image(new FileInputStream("src\\main\\resources\\Images\\Default.png"));
        ImageView imageView = new ImageView();
        imageView.setImage(image);
        ColorAdjust colorAdjust = new ColorAdjust();
        colorAdjust.setBrightness(0);
        colorAdjust.setContrast(1);
        colorAdjust.setHue(0.25);
        colorAdjust.setSaturation(0.35);
        imageView.setEffect(colorAdjust);
        imageView.setFitHeight(40);
        imageView.setFitWidth(40);
        HBox hBox = new HBox();
        Pane pane = new Pane();
        pane.setPrefSize(10,10);
        hBox.getChildren().addAll(imageView,pane,label);
        hBox.setAlignment(Pos.TOP_LEFT);
        Message_UI.setSpacing(10);
        Message_UI.getChildren().add(hBox);
    }

    public void message_receive(String message) throws FileNotFoundException {
        Label label = new Label();
        label.setWrapText(true);
        label.setMaxWidth(180);
        label.setFont(new Font(15));
        label.setText(message);
        label.setPadding(new Insets(10,10,10,10));
        label.setTextFill(Color.valueOf("#cdbe91"));
        label.setStyle("-fx-border-width: 3;-fx-border-color: #785A28;-fx-border-radius: 20;");
        Image image = new Image(new FileInputStream("src\\main\\resources\\Images\\Default.png"));
        ImageView imageView = new ImageView();
        imageView.setImage(image);
        ColorAdjust colorAdjust = new ColorAdjust();
        colorAdjust.setBrightness(0);
        colorAdjust.setContrast(1);
        colorAdjust.setHue(0.25);
        colorAdjust.setSaturation(0.35);
        imageView.setEffect(colorAdjust);
        imageView.setFitHeight(40);
        imageView.setFitWidth(40);
        HBox hBox = new HBox();
        Pane pane = new Pane();
        pane.setPrefSize(10,10);
        hBox.getChildren().addAll(label,pane,imageView);
        hBox.setAlignment(Pos.TOP_RIGHT);
        Message_UI.setSpacing(10);
        Message_UI.getChildren().add(hBox);
    }
    public void image_receive(String name) throws FileNotFoundException {
        Image imagex = new Image(new FileInputStream("src\\main\\resources\\Images\\Default.png"));
        ImageView imageViewx = new ImageView();
        imageViewx.setImage(imagex);
        ColorAdjust colorAdjust = new ColorAdjust();
        colorAdjust.setBrightness(0);
        colorAdjust.setContrast(1);
        colorAdjust.setHue(0.25);
        colorAdjust.setSaturation(0.35);
        imageViewx.setEffect(colorAdjust);
        imageViewx.setFitHeight(40);
        imageViewx.setFitWidth(40);
        HBox hBox = new HBox();
        if(name.contains(".png") || name.contains(".jpg")) {
            Image image = new Image(new FileInputStream(name));
            ImageView imageView = new ImageView();
            imageView.setImage(image);
            imageView.setFitHeight(200);
            imageView.setFitWidth(200);
            Pane pane = new Pane();
            pane.setPrefSize(10,10);
            hBox.getChildren().addAll(imageView, pane, imageViewx);
        }
        else {
            Label label = new Label();
            label.setWrapText(true);
            label.setMaxWidth(180);
            label.setFont(new Font(15));
            label.setText(name);
            label.setPadding(new Insets(10,10,10,10));
            label.setTextFill(Color.valueOf("#cdbe91"));
            label.setStyle("-fx-border-width: 3;-fx-border-color: #785A28;-fx-border-radius: 20;");
            Pane pane = new Pane();
            pane.setPrefSize(10,10);
            hBox.getChildren().addAll(label, pane, imageViewx);
        }
        hBox.setAlignment(Pos.TOP_RIGHT);
        Message_UI.setSpacing(10);
        Message_UI.getChildren().add(hBox);
    }

    public void image_send(String name) throws FileNotFoundException {
        Image imagex = new Image(new FileInputStream("src\\main\\resources\\Images\\Default.png"));
        ImageView imageViewx = new ImageView();
        imageViewx.setImage(imagex);
        ColorAdjust colorAdjust = new ColorAdjust();
        colorAdjust.setBrightness(0);
        colorAdjust.setContrast(1);
        colorAdjust.setHue(0.25);
        colorAdjust.setSaturation(0.35);
        imageViewx.setEffect(colorAdjust);
        imageViewx.setFitHeight(40);
        imageViewx.setFitWidth(40);
        HBox hBox = new HBox();
        if(name.contains(".png") || name.contains(".jpg")) {
            Image image = new Image(new FileInputStream(name));
            ImageView imageView = new ImageView();
            imageView.setImage(image);
            imageView.setFitHeight(200);
            imageView.setFitWidth(200);
            Pane pane = new Pane();
            pane.setPrefSize(10, 10);
            hBox.getChildren().addAll(imageViewx, pane, imageView);
            hBox.setAlignment(Pos.TOP_LEFT);
        }
        else
        {
            Label label = new Label();
            label.setWrapText(true);
            label.setMaxWidth(180);
            label.setFont(new Font(15));
            label.setText(name);
            label.setPadding(new Insets(10,10,10,10));
            label.setTextFill(Color.valueOf("#cdbe91"));
            label.setStyle("-fx-border-width: 3;-fx-border-color: #785A28;-fx-border-radius: 20;");
            Pane pane = new Pane();
            pane.setPrefSize(10,10);
            hBox.getChildren().addAll(imageViewx, pane, label);
            hBox.setAlignment(Pos.TOP_LEFT);
        }
        Message_UI.setSpacing(10);
        Message_UI.getChildren().add(hBox);
    }
    public Controller() throws IOException {
        receive_message = new Thread(new Runnable() {
            @Override
            public void run() {
                while (sent) {
                    try {
                        message = input.readUTF();
                        Platform.runLater(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    message_receive(message);
                                } catch (FileNotFoundException e) {
                                    e.printStackTrace();
                                }
                            }
                        });
                        System.out.println(message);
                        messages_array.add(message);

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        Timeline timeline = new Timeline(
                new KeyFrame(Duration.seconds(5),
                        new EventHandler<ActionEvent>() {
                            @Override
                            public void handle(ActionEvent event) {
                                for (int i = 0, h = 0; i < User_list.size(); i++) {

                                    if (User_list.get(i).getString("user").equals(Login.username)) {
                                        h--;
                                        continue;
                                    }
                                    if (!User_list.get(i).equals(user_database.find().into(new ArrayList<>()).get(i))) {
                                        User_list.set(i, user_database.find().into(new ArrayList<>()).get(i));
                                        Friend_list.getItems().set(i + h, friend_list(User_list.get(i).getString("user"), User_list.get(i).getString("Status")));
                                    }
                                }
                            }
                        }));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
        receive_file = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    try {
                        System.out.println("Waiting");
                        String filename = input_Data.readUTF();
                        DataOutputStream output0 = new DataOutputStream(new FileOutputStream(Default_download + filename));
                        file_size = input_Data.readLong();
                        byte[] buffer = new byte[100000];
                        file_Max = file_size;
                        while (file_size > 0 && (read_data = input_Data.read(buffer, 0, (int) Math.min(buffer.length, file_size))) != -1) {
                            output0.write(buffer, 0, read_data);
                            outputUI = (1 - ((float) file_size / (float) file_Max));
                            System.out.println(outputUI);
                            file_size -= read_data;
                        }
                        output0.close();
                        Platform.runLater(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    image_receive(Default_download + filename);
                                } catch (FileNotFoundException e) {
                                    e.printStackTrace();
                                }
                            }
                        });

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        receive_message.start();
        receive_file.start();
    }

    @FXML
    void Start_Chat(MouseEvent event) {
       if (Friend_list.getSelectionModel().getSelectedIndex() >= user_pos) {
           person_to_talk = User_list.get(Friend_list.getSelectionModel().getSelectedIndex() + 1).get("user").toString();
       }
       else {
           person_to_talk = User_list.get(Friend_list.getSelectionModel().getSelectedIndex()).get("user").toString();
       }

        Maximus.setVisible(false);
        new SlideInRight(scroller).play();
        new SlideInRight(message_sending_panel).play();
    }

    public HBox friend_list(String x, String status){
        Circle statusG = new Circle();
        statusG.setRadius(5);
        statusG.setFill(Color.valueOf("#04ff00"));
        Circle statusR = new Circle();
        statusR.setRadius(5);
        statusR.setFill(Color.RED);
        Label label = new Label();
        //label.setWrapText(true);
        label.setMaxWidth(200);
        label.setFont(new Font(15));
        label.setText(x);
        label.setPadding(new Insets(10,10,10,10));
        label.setTextFill(Color.valueOf("#cdbe91"));
        label.setStyle("-fx-border-width: 3;-fx-border-color: #785A28;-fx-border-radius: 20;");
        HBox hBox = new HBox();
        hBox.setAlignment(Pos.CENTER_LEFT);
        Pane pane = new Pane();
        pane.setPadding(new Insets(5, 5, 5, 5));
        if (status.equals("Online")){
            hBox.getChildren().addAll(statusG, pane, label);
            return hBox;
        }
        else {
            hBox.getChildren().addAll(statusR, pane, label);
            return hBox;
        }

    }


    @FXML
    void enable_max(ActionEvent event) {
        if(!Maximus.isVisible()){
            Maximus.setVisible(true);
            Maximus.setDisable(false);
            new SlideOutRight(scroller).play();
            new SlideOutRight(message_sending_panel).play();
            Settings_windows.setVisible(false);
            Settings_windows.setDisable(true);
            Add_friend_panel.setVisible(false);
            Add_friend_panel.setDisable(true);
        }
        else {
            Maximus.setVisible(false);
            Maximus.setDisable(true);
            new SlideInRight(scroller).play();
            new SlideInRight(message_sending_panel).play();
        }

    }



    @FXML
    void send_button(ActionEvent event) {

        String message1 = Messeging_text.getText();
        Messeging_text.clear();
        try {
            //output.writeUTF(message + "#ID 1");
            output.writeUTF(message1 + "#" + person_to_talk);
            message_send(message1);
            messages_array.add(message1);
        }
        catch (IOException e) {
            e.printStackTrace();
        }

    }


    @FXML
    void Exit(ActionEvent event) throws IOException {
        user_database.updateOne(Filters.eq("user", Login.username), Updates.set("Status", "Offline"));
        sent = false;
        try {
            output.writeUTF("%%$$&&");
            dataOutputStream.writeUTF("%%$$&&");
            socket.close();
            socketF.close();
            input.close();
            input_Data.close();
            output.close();
            dataOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.exit(0);
    }
    @FXML
    void Start_drag(MouseEvent event) {
        x = event.getSceneX();
        y = event.getSceneY();
    }


    @FXML
    void mouse_draged(MouseEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setX(event.getScreenX() - x);
        stage.setY(event.getScreenY() - y);
    }

    @FXML
    void LogOut_button(ActionEvent event) throws IOException {
        user_database.updateOne(Filters.eq("user", Login.username), Updates.set("Status", "Offline"));
        try {
            output.writeUTF("%%$$&&");
            sent = false;
            socket.close();
            input.close();
            output.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
        App.setRoot("/LoginUI");
    }

    @FXML
    void image_send(ActionEvent event) {
        System.out.println("Call");
        try {
            FileChooser fileChooser = new FileChooser();
            File file = fileChooser.showOpenDialog(null);
            byte[] bytes = new byte[(int) file.length()];
            DataInputStream input_Data0 = new DataInputStream(new FileInputStream(file));
            input_Data0.readFully(bytes, 0, bytes.length);
            dataOutputStream.writeUTF( person_to_talk + "#" + file.getName());
            dataOutputStream.writeLong(bytes.length);
            dataOutputStream.write(bytes, 0, bytes.length);
            dataOutputStream.flush();
            image_send(file.getPath());
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    @FXML
    void download_save(ActionEvent event) {
        DirectoryChooser directoryChooser = new DirectoryChooser();
        File file = directoryChooser.showDialog(null);
        Default_download = file.getPath();
        download_location.setText(Default_download);
    }

    @FXML
    void Settings_panel(ActionEvent event) {
        if (Settings_windows.isVisible()) {
            Settings_windows.setVisible(false);
            Settings_windows.setDisable(true);
            new SlideInRight(scroller).play();
            new SlideInRight(message_sending_panel).play();
        }
        else {
            Settings_windows.setVisible(true);
            Settings_windows.setDisable(false);
            Maximus.setVisible(false);
            Maximus.setDisable(true);
            Add_friend_panel.setDisable(true);
            Add_friend_panel.setVisible(false);
            new SlideOutRight(scroller).play();
            new SlideOutRight(message_sending_panel).play();
        }
    }

    @FXML
    void AddFriend_panel(ActionEvent event) {
        if (Add_friend_panel.isVisible()) {
            Add_friend_panel.setVisible(false);
            Add_friend_panel.setDisable(true);
            new SlideInRight(scroller).play();
            new SlideInRight(message_sending_panel).play();
        }
        else {
            Add_friend_panel.setVisible(true);
            Add_friend_panel.setDisable(false);
            Maximus.setVisible(false);
            Maximus.setDisable(true);
            Settings_windows.setDisable(true);
            Settings_windows.setVisible(false);
            for (Document x : User_list) {
                if(x.getString("user").equals(Login.username)) {
                    Request_list.getItems().addAll(x.getString("Requests").split(","));
                }
            }
            new SlideOutRight(scroller).play();
            new SlideOutRight(message_sending_panel).play();
        }
    }

    @FXML
    void Add_friend(ActionEvent event) {
        StringBuffer srh = new StringBuffer(search_list.getSelectionModel().getSelectedItems().toString());
        srh.deleteCharAt(0);
        srh.deleteCharAt(srh.length() - 1);
        System.out.println(srh);
        for (Document x : User_list) {
            if (x.getString("user").equals(srh.toString())) {
                System.out.println(srh);
                StringBuffer stringBuffer = new StringBuffer(User_list.get(User_list.indexOf(x)).getString("Requests"));
                if (stringBuffer.toString().equals("")) {
                    stringBuffer.append(Login.username);
                }
                else {
                    stringBuffer.append("," + Login.username);
                }
                user_database.updateOne(Filters.eq("user", srh.toString()), Updates.set("Requests", stringBuffer.toString()));
            }
        }

    }

    @FXML
    void Remove_friend(ActionEvent event) {

    }

    @FXML
    void Search_friend(ActionEvent event) {
        search_list.getItems().clear();
        for (Document x : User_list) {
            if (x.getString("user").contains(Search_friends.getText())) {
                search_list.getItems().add(x.getString("user"));
            }
        }

    }
    @FXML
    void Add_Request(ActionEvent event) {
        StringBuffer srh = new StringBuffer(Request_list.getSelectionModel().getSelectedItems().toString());
        srh.deleteCharAt(0);
        srh.deleteCharAt(srh.length() - 1);
        for (Document x : User_list) {
            if (x.getString("user").equals(srh.toString())) {
                StringBuffer stringBuffer = new StringBuffer(User_list.get(User_list.indexOf(x)).getString("Friends"));
                StringBuffer userbuffer = new StringBuffer(User_list.get(User_list.indexOf(userDoc)).getString("Friends"));
                if (stringBuffer.toString().equals("")) {
                    stringBuffer.append(Login.username);
                }
                else {
                    stringBuffer.append("," + Login.username);
                }
                if (userbuffer.toString().equals("")) {
                    userbuffer.append(srh.toString());
                }
                else {
                    userbuffer.append("," + srh.toString());
                }

                user_database.updateOne(Filters.eq("user", srh.toString()), Updates.set("Friends", stringBuffer.toString()));
                user_database.updateOne(Filters.eq("user", Login.username), Updates.set("Friends", userbuffer.toString()));
            }
        }
        for (Document x : User_list) {
            if(x.getString("user").equals(Login.username)) {
                ListView<String> listView = new ListView<>();
                listView.getItems().addAll(x.getString("Requests").split(","));
                listView.getItems().remove(listView.getItems().indexOf(srh.toString()));
                StringBuffer sb = new StringBuffer();
                for (String xl : listView.getItems()) {
                    Request_list.getItems().add(xl);
                    if (listView.getItems().indexOf(xl) == 0) {
                        sb.append(xl);
                    }
                    else {
                        sb.append("," + xl);
                    }
                }
                user_database.updateOne(Filters.eq("user", Login.username), Updates.set("Requests", sb.toString()));
            }
        }
    }


}
