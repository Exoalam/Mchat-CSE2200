package com.MChat;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import org.bson.Document;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;

public class Server {
    static Vector<Client_handler> Clients = new Vector<Client_handler>();
    private static String Database_Connection = "mongodb+srv://Server:Server1234@mchat.xvkt0.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";
    static int client_count = 0;
    public static void main (String[] args) throws IOException {
        MongoClient mongoClient = MongoClients.create(Database_Connection);
        File Default = new File("C:\\Users\\nafiu\\Desktop\\Server");
        Default.mkdirs();
        MongoCollection<Document> database = mongoClient.getDatabase("chat").getCollection("chitchat");
        FileShare_Server fileShare_server = new FileShare_Server();
        Thread threadf = new Thread(fileShare_server);
        threadf.start();
        ServerSocket serverSocket = new ServerSocket(1234);
        Socket client;
        while (true) {
            client = serverSocket.accept();
            System.out.println("Connection established with " + client);
            DataInputStream input = new DataInputStream(client.getInputStream());
            DataOutputStream output = new DataOutputStream(client.getOutputStream());
            Client_handler client_handler = new Client_handler(input.readUTF(), client, input, output, database);
            Thread thread = new Thread(client_handler);
            Clients.add(client_handler);
            thread.start();
            System.out.println("Client " + client + "is online now");
            client_count++;
        }
    }
}
