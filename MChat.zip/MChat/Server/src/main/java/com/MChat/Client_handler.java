package com.MChat;

import com.mongodb.client.MongoCollection;
import org.bson.Document;

import javax.swing.text.DateFormatter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.StringTokenizer;

public class Client_handler implements Runnable {

    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
    LocalDateTime time = LocalDateTime.now();
    private String clientID;
    Socket socket;
    final DataInputStream input;
    final DataOutputStream output;
    boolean is_Login;
    MongoCollection<Document> database;

    Client_handler(String name, Socket s, DataInputStream in, DataOutputStream out, MongoCollection<Document> d) {
        this.clientID = name;
        this.socket = s;
        this.input = in;
        this.output = out;
        is_Login = true;
        this.database = d;
    }

    @Override
    public void run() {
        String incoming_data;
        while (true) {
            try {
                incoming_data = input.readUTF();
                System.out.println(incoming_data);

                if (incoming_data.equals("%%$$&&")) {
                    this.is_Login = false;
                    this.socket.close();;
                    break;
                }

                StringTokenizer split = new StringTokenizer(incoming_data,"#");
                String message = split.nextToken();
                String ID = split.nextToken();

                for (Client_handler client : Server.Clients) {

                    if (client.clientID.equals(ID) && client.is_Login == true) {
                        Document data = new Document("Message",incoming_data).append("Time",formatter.format(time)).append("ID",this.clientID);
                        database.insertOne(data);
                        client.output.writeUTF(this.clientID + " -> " + message);
                        break;
                    }
                }
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }
        try {
            this.input.close();
            this.output.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
