package com.MChat;

import java.io.*;
import java.net.Socket;
import java.util.StringTokenizer;

public class FileShare_client implements Runnable{

    Socket socket;
    String user;
    final DataInputStream input_Data;
    final DataOutputStream dataOutputStream;
    int read_data;
    long file_size;
    long file_Max;
    static float outputUI;
    boolean isOnline;
    public FileShare_client(Socket s, DataInputStream in, DataOutputStream out, String n, boolean b){
        this.socket = s;
        this.input_Data = in;
        this.dataOutputStream = out;
        this.user = n;
        this.isOnline = b;
    }
    @Override
    public void run() {
        while (true) {
            try {
                //Receiving Part
                //input_Data = new DataInputStream(socket.getInputStream());
                System.out.println("Waiting to receive");
                String incoming_data = input_Data.readUTF();
                if(incoming_data.equals("%%$$&&")) {
                    this.socket.close();
                    this.isOnline = false;
                    break;
                }
                StringTokenizer split = new StringTokenizer(incoming_data,"#");
                String user_name = split.nextToken();
                String filename = split.nextToken();
                DataOutputStream output0 = new DataOutputStream(new FileOutputStream("C://Users//nafiu//Desktop//Server//" + filename));
                file_size = input_Data.readLong();
                byte[] buffer = new byte[100000];
                file_Max = file_size;
                while (file_size > 0 && (read_data = input_Data.read(buffer, 0, (int) Math.min(buffer.length, file_size))) != -1) {
                    output0.write(buffer, 0, read_data);
                    outputUI = ((1 - ((float) file_size / (float) file_Max)) * 100);
                    System.out.println(outputUI);
                    file_size -= read_data;
                }
                System.out.println("100");
                output0.close();
                //Sending Part

                try {
                    System.out.println(user_name);
                    File file = new File("C://Users//nafiu//Desktop//Server//" + filename);
                    byte[] bytes = new byte[(int) file.length()];
                    DataInputStream input_Data0 = new DataInputStream(new FileInputStream(file));
                    input_Data0.readFully(bytes, 0, bytes.length);
                    //dataOutputStream = new DataOutputStream(socket.getOutputStream());
                    for (FileShare_client client:FileShare_Server.clients) {
                        if (client.user.equals(user_name) && client.isOnline == true) {
                            client.dataOutputStream.writeUTF(file.getName());
                            client.dataOutputStream.writeLong(bytes.length);
                            client.dataOutputStream.write(bytes, 0, bytes.length);
                            client.dataOutputStream.flush();
                        }
                    }
                    file = null;

                }
                catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                catch (IOException e) {
                    e.printStackTrace();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
