package com.MChat;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;

public class FileShare_Server implements Runnable{

    static Vector<FileShare_client> clients = new Vector<>();
    ServerSocket serverSocket = new ServerSocket(5555);
    Socket socket;
    public FileShare_Server() throws IOException {
    }

    @Override
    public void run() {
        while(true) {
            try {
                System.out.println("Waiting");
                socket = serverSocket.accept();
                System.out.println("Connection Established");
                DataInputStream input_Data = new DataInputStream(socket.getInputStream());
                DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());
                FileShare_client fileShare_client = new FileShare_client(socket, input_Data, dataOutputStream, input_Data.readUTF(), true);
                Thread thread = new Thread(fileShare_client);
                clients.add(fileShare_client);
                thread.start();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
